CREATE TABLE vendaparcelas(
  id INTEGER NOT NULL,
  idvenda INTEGER NOT NULL,
  dataemissao DATE NOT NULL,
  parcela INTEGER NOT NULL,
  valorparcela NUMERIC(10,2) NOT NULL,
  datapagto DATE,
  PRIMARY KEY(id),
  FOREIGN KEY(idvenda) REFERENCES venda(id)
);

 

INSERT INTO vendaparcelas VALUES(1,1,'2019-01-05',1,100.0, NULL);
INSERT INTO vendaparcelas VALUES(2,1,'2019-01-05',2,100.0, NULL);
INSERT INTO vendaparcelas VALUES(3,2,'2019-01-05',1,50.0, NULL);
INSERT INTO vendaparcelas VALUES(4,2,'2019-01-05',2,50.0, NULL);
INSERT INTO vendaparcelas VALUES(5,3,'2019-01-05',1,200.0, NULL);
INSERT INTO vendaparcelas VALUES(6,4,'2019-01-05',1,300.0, NULL);