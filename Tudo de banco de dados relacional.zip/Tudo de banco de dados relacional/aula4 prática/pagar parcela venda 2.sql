UPDATE vendaparcelas
SET datapagto = '2023-09-15'
WHERE idvenda = 2
AND parcela = 1