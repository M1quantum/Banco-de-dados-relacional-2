UPDATE vendaparcelas
SET datapagto = '2023-09-21'
WHERE idvenda = 1
AND parcela = 1