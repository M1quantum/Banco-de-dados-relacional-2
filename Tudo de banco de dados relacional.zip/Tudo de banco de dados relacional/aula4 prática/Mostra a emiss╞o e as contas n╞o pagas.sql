SET sql_mode='ANSI'

SELECT v.id, v.datemissao,
   (SELECT COUNT(p.id) 
	 FROM vendaparcelas p
    WHERE p.idvenda = v.id
    and p.datapagto IS NULL) AS naopagas,
    
    (SELECT COUNT(p.id) 
	 FROM vendaparcelas p
    WHERE p.idvenda = v.id
    and p.datapagto IS NOT NULL) AS pagas,
    
    (SELECT COUNT(p.id)
    FROM vendaparcelas p
    WHERE p.idvenda = v.id
    AND p.datapagto IS NOT NULL) || '/' ||
    
    (SELECT COUNT(p.id)
    FROM vendaparcelas p 
    WHERE p.idvenda = v.id) AS parcelaspagas
    
FROM venda v