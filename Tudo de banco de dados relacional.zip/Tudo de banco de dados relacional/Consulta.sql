SELECT id,
   IF (CHAR_LENGTH(nome) > 10,
          CONCAT (LEFT(NOME,10), '...'),
                NOME) SOMA
FROM pessoa;
