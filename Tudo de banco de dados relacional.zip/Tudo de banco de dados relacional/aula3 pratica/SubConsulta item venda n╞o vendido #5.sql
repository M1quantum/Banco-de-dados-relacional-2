SELECT p.*
FROM produto p
WHERE p.id NOT IN (SELECT idproduto
                        FROM itemvenda); 