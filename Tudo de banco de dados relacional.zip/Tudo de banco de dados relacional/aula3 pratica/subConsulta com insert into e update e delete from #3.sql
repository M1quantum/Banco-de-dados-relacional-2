INSERT INTO teste(id, nome, telefone, idregiao)
(SELECT id, nome, telefone, idregiao
FROM cliente);

UPDATE teste 
SET idregiao = (SELECT id 
                FROM regiao
                WHERE descricao = 'SAO PAULO')
                
WHERE idregiao = 4;

DELETE FROM teste
WHERE idregiao = (SELECT id
                  FROM regiao
                  WHERE descricao = 'CAMPINAS');