SELECT v.id, v.idformapagto, f.descricao
FROM venda v, formapagto f
WHERE v.idformapagto = f.id
AND v.id IN (SELECT v.id 
             FROM venda v
             WHERE v.datemissao BETWEEN '2019-01-01' AND '2019-06-30');