CREATE TABLE teste(
id INTEGER NOT NULL,
nome VARCHAR(60),
telefone VARCHAR(15),
idregiao INTEGER
);
