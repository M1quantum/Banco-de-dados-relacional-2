SELECT p.*
FROM produto p
WHERE p.id IN (SELECT idproduto
                        FROM itemvenda); 