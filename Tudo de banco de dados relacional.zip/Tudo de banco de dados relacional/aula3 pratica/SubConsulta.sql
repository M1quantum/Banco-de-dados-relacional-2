SELECT id, descricao, precodevenda
FROM produto
WHERE precodevenda > (SELECT AVG(precodevenda)
                     FROM produto);
