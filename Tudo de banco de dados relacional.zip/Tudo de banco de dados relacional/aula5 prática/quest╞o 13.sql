SELECT t.id, t.descricao, t.qtde
FROM (
    SELECT a.id, a.descricao, COUNT(b.id) AS qtde
    FROM formapagto a
    LEFT JOIN venda b ON b.idformapagto = a.id
    GROUP BY a.id
) AS t
WHERE qtde = (
    SELECT MIN(qtde) AS qtde
    FROM (
        SELECT a.id, a.descricao, COUNT(b.id) AS qtde
        FROM formapagto a
        LEFT JOIN venda b ON b.idformapagto = a.id
        GROUP BY a.id
    ) AS t
);