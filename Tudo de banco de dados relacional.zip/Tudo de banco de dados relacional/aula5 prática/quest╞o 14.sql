SELECT *
FROM venda
WHERE idcliente IN (
    SELECT id
    FROM cliente
    WHERE municipio = 'ITAPIRA'
);