CREATE TABLE cliente2 (
 id INTEGER, 
 nome VARCHAR(60),
 idregiao INTEGER 
);

INSERT INTO cliente2
(SELECT a.id, a.nome, a.idregiao
 FROM cliente a, regiao b
 WHERE b.id = a.idregiao
 AND b.descricao = 'BAIXA MOGIANA')