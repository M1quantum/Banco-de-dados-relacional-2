SELECT t.id, t.descricao, t.qtde
FROM (SELECT a.id, a.descricao, COUNT(*) AS qtde
            FROM formapagto a, venda b
            WHERE b.idformapagto = a.id
            GROUP BY a.id) AS t
WHERE qtde = (SELECT MAX(qtde) AS qtde
              FROM (SELECT a.id, a.descricao, COUNT(*) AS qtde
                    FROM formapagto a, venda b
                    WHERE b.idformapagto = a.id
                    GROUP BY a.id) AS t)