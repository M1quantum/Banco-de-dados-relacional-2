delimiter $
CREATE OR REPLACE FUNCTION mensagem(texto CHAR(20)) 
RETURNS CHAR(50)
BEGIN 
   DECLARE mens CHAR(50);
   SET mens = CONCAT ('Olá,', texto, '!');
   RETURN mens;
END  $
delimiter ;
SELECT mensagem('Miguel');