SELECT SUM(salario), idcargo
FROM empregado
GROUP BY idcargo
HAVING SUM(salario)>2500
ORDER BY idcargo 