SELECT MONTH(v.datemissao), p.descricao, p.precodecompra, i.quantidade, i.precounitario
FROM produto p, itemvenda i, venda v
WHERE p.id = i.idproduto
AND i.idvenda = v.id
AND YEAR(v.datemissao) = 2019
AND MONTH(v.datemissao) = 1