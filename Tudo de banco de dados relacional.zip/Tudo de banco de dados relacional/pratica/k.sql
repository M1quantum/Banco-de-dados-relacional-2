SELECT LPAD('banco', 10, '.'),
           RPAD('banco', 10, '=');